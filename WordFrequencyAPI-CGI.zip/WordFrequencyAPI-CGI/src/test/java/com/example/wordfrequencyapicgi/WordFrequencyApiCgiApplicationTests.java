package com.example.wordfrequencyapicgi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordFrequencyApiCgiApplicationTests {

    @Test
    void contextLoads() {
    }

}
